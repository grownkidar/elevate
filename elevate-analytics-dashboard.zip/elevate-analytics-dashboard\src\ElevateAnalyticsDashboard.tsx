﻿[PASTE THE FULL CONTENT OF ElevateAnalyticsDashboard.tsx HERE]
