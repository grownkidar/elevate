﻿import React from "react";
import ElevateAnalyticsDashboard from "./ElevateAnalyticsDashboard";

const App: React.FC = () => {
  return <ElevateAnalyticsDashboard />;
};

export default App;
