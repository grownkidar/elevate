﻿# elevate-analytics-dashboard

Elevate Analytics Dashboard — React + TypeScript demo using Recharts.

How to use
- Open this repository in CodeSandbox (Import from GitHub).
- Or clone locally and run:
  - npm install
  - npm run dev
